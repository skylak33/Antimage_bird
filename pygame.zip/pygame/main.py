import pygame
import random

# Инициализируем Pygame
pygame.init()

# Устанавливаем размер окна
WIDTH = 2520
HEIGHT = 1680
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Устанавливаем заголовок окна
pygame.display.set_caption("Летающая птица")

# Загружаем изображения
bird_img = pygame.image.load("bird.png")
reverse_pipe_img = pygame.image.load("2.png")
pipe_img = pygame.image.load("3.png")
long_pipe_img = pygame.image.load("4.png")
long_reverse_pipe_img = pygame.image.load("1.png")
dot_img = pygame.image.load("bodka.png")
dot1_img = pygame.image.load("bodka.png")
# Устанавливаем параметры игры
bird_x = 50
bird_y = 250
bird_speed = 1
gravity = 0.1
pipe_x = WIDTH
pipe_gap = 150
pipe_width = 50
pipe_height = HEIGHT - pipe_gap - 100
pipe_speed = 10
score = 0
font = pygame.font.Font(None, 40)

# Основной цикл игры
running = True
bruh = 0
while running:

    # Обработка событий
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                bird_speed = -5

    # Обновление позиции птицы
    bird_speed += gravity
    bird_y += bird_speed

    # Обновление позиции труб
    pipe_x -= pipe_speed

    if pipe_x < -pipe_width:
        pipe_x = WIDTH
        pipe_height = random.randint(100, HEIGHT - pipe_gap - 100)
        score += 1
        pipe_speed += 0.25
        bruh = random.randint(0, 3)

    # Рендеринг элементов игры
    screen.fill((135, 206, 235))  # Заливка фона
    screen.blit(bird_img, (bird_x, bird_y))  # Отрисовка птицы
    if bruh % 4 == 0:
        screen.blit(pipe_img, (pipe_x, 0))  # Отрисовка верхней трубы
        screen.blit(reverse_pipe_img, (pipe_x,800))  # Отрисовка нижней трубы
        screen.blit(long_pipe_img, (pipe_x,1300))  # Отрисовка нижней трубы
        screen.blit(long_pipe_img, (pipe_x,1000))  # Отрисовка нижней трубы
        screen.blit(dot1_img, (pipe_x,0))  # Отрисовка точек
        screen.blit(dot_img, (pipe_x,800))  # Отрисовка точек
    elif bruh % 4 == 1:
        screen.blit(pipe_img, (pipe_x, 300))  # Отрисовка верхней трубы
        screen.blit(long_reverse_pipe_img, (pipe_x, 0))
        screen.blit(long_reverse_pipe_img, (pipe_x, 100))
        screen.blit(reverse_pipe_img, (pipe_x,1400))  # Отрисовка нижней трубы
        screen.blit(dot1_img, (pipe_x,0))  # Отрисовка нижней трубы
        screen.blit(dot_img, (pipe_x,1400))  # Отрисовка нижней трубы
    elif bruh % 4 == 2:
        screen.blit(pipe_img, (pipe_x, 600))  # Отрисовка верхней трубы
        screen.blit(long_reverse_pipe_img, (pipe_x, 0))
        screen.blit(long_reverse_pipe_img, (pipe_x, 200))
        screen.blit(long_reverse_pipe_img, (pipe_x, 400))
        screen.blit(reverse_pipe_img, (pipe_x,1400))  # Отрисовка нижней трубы
        screen.blit(dot1_img, (pipe_x,0))  # Отрисовка нижней трубы
        screen.blit(dot_img, (pipe_x,1400))  # Отрисовка нижней трубы
    elif bruh % 4 == 3:
        screen.blit(pipe_img, (pipe_x, 0))  # Отрисовка верхней трубы
        screen.blit(reverse_pipe_img, (pipe_x,1400))  # Отрисовка нижней трубы
        screen.blit(dot1_img, (pipe_x,0))  # Отрисовка нижней трубы
        screen.blit(dot_img, (pipe_x,1400))  # Отрисовка нижней трубы
    score_text = font.render(f"Score: {score}", True, (0, 0, 0))  # Рендеринг счета
    screen.blit(score_text, (10, 10))  # Отрисовка счета

    
    # Обработка столкновений
    if bird_y < 0 or bird_y > HEIGHT + 200:
        running = False
    bird_rect = pygame.Rect(bird_x, bird_y, bird_img.get_width(), bird_img.get_height())
    pipe_rect_top = pygame.Rect(pipe_x, 0, pipe_width, pipe_height)
    pipe_rect_bottom = pygame.Rect(pipe_x, 1080, pipe_width, pipe_height)
    dot_rect_bottom = pygame.Rect(pipe_x, 0, 1, 1)
    dot_rect_top = pygame.Rect(pipe_x, 0, 1, 1)
    if bruh % 2 == 0: 
        dot_rect_bottom = pygame.Rect(pipe_x, 800, 1, 1)
        dot_rect_top = pygame.Rect(pipe_x, 0, 1, 1)
    elif bruh % 2 == 1:
        dot_rect_bottom = pygame.Rect(pipe_x, 1400, 1, 1)
        dot_rect_top = pygame.Rect(pipe_x, 0, 1, 1)
    elif bruh % 2 == 2:
        dot_rect_bottom = pygame.Rect(pipe_x, 1400, 1, 1)
        dot_rect_top = pygame.Rect(pipe_x, 0, 1, 1)
    elif bruh % 2 == 3:
        dot_rect_bottom = pygame.Rect(pipe_x, 1400, 1, 1)
        dot_rect_top = pygame.Rect(pipe_x, 0, 1, 1)

    if bird_rect.colliderect(dot_rect_top) or bird_rect.colliderect(dot_rect_bottom):
        running = False

    # Обновление экрана
    pygame.display.flip()

# Выход из Pygame
#pygame.quit()